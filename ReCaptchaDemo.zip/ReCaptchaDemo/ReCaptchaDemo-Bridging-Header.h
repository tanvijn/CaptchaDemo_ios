//
//  ReCaptchaDemo-Bridging-Header.h
//  ReCaptchaDemo
//
//  Created by Tavni Jain on 2020-10-09.
//  Copyright © 2020 Tavni Jain. All rights reserved.
//

#ifndef ReCaptchaDemo_Bridging_Header_h
#define ReCaptchaDemo_Bridging_Header_h
#import "CaptchaWrapper.h"

#endif /* ReCaptchaDemo_Bridging_Header_h */
