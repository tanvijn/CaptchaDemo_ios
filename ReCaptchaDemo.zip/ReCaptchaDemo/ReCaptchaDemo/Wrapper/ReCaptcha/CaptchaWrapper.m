//
//  CaptchaWrapper.m
//
//  Copyright © 2020 Tanvi jain. All rights reserved.
//

#import "CaptchaWrapper.h"
#import <WebKit/WebKit.h>
#import <JavaScriptCore/JavaScriptCore.h>


@interface CaptchaWrapper()<WKNavigationDelegate,WKScriptMessageHandler> {
    UIActivityIndicatorView *activityView;
}
@property(nonatomic, strong) WKWebView *webView;
@property(nonatomic, strong) UIViewController *viewController;
@property(nonatomic, strong) NSString *captchaSiteKey;
@property(nonatomic, strong) NSString *baseUrl;
@property(nonatomic, copy) void (^captchaCompletion)(NSDictionary *data);
@end

@implementation CaptchaWrapper

- (instancetype)initReCaptchaWithApiKey:(NSString *)captchaSiteKey baseURL:(NSString *)baseUrl {
    self = [super init];
    if (self) {
        NSAssert(captchaSiteKey && [captchaSiteKey length], @"Captcha Site Key cannot be null");
        NSAssert(captchaSiteKey && [captchaSiteKey length], @"BaseURL cannot be null");
        
        self.captchaSiteKey =  captchaSiteKey;
        self.baseUrl =  baseUrl;
        
    }
    return self;
}

- (void)showLoader {
    activityView = [[UIActivityIndicatorView alloc]
                    initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    
    activityView.center=self.viewController.view.center;
    [self.viewController.view addSubview:activityView];
    [activityView startAnimating];
    [self.viewController.view bringSubviewToFront:activityView];
}
- (void)hideLoader {
    [activityView stopAnimating];
    [activityView removeFromSuperview];
}
- (void)executeScript {
    
    [self.webView evaluateJavaScript:@"execute();" completionHandler:^(id dic, NSError *error) {
    }];
   
}
- (void)validateReCaptcha:(UIViewController*)viewC withFrame:(CGRect)frame completionHandler:(void(^)(NSDictionary *data))captchaComp {
    NSMutableDictionary *dictCompletion = [[NSMutableDictionary alloc] init];
    if(viewC == nil)
    {
        [dictCompletion setObject:@"View Controller for captcha cannot be nil!" forKey:@"error"];
        captchaComp(dictCompletion);
    }
    else if(frame.size.height == 0 || frame.size.width == 0)
    {
        [dictCompletion setObject:@"Frame for captcha challenge cannot be zero!" forKey:@"error"];
        captchaComp(dictCompletion);
        
    }
    else {
        self.viewController = viewC;
        self.captchaCompletion = captchaComp;
        
        [self showLoader];
        WKUserContentController *wkUController = [[WKUserContentController alloc] init];
        [wkUController addScriptMessageHandler:self name:@"recaptcha"];
        WKWebViewConfiguration *wkWebConfig = [[WKWebViewConfiguration alloc] init];
        wkWebConfig.userContentController = wkUController;
        self.webView = [[WKWebView alloc] initWithFrame:frame configuration:wkWebConfig];
        self.webView.navigationDelegate = self;
        NSURL *url = [NSURL URLWithString:self.baseUrl];
        NSString* filePath = [[NSBundle mainBundle] pathForResource:@"recaptcha" ofType:@"html"];
        NSString *strCotent = [NSString stringWithContentsOfFile:filePath encoding:NSUTF8StringEncoding error:nil];
        strCotent = [strCotent stringByReplacingOccurrencesOfString:@"${apikey}" withString:self.captchaSiteKey];
        [self.webView loadHTMLString:strCotent baseURL:url];
        self.webView.hidden = true;
        [self.viewController.view addSubview:self.webView];
    }
}
#pragma mark Webview delegate methods
- (void)webView:(WKWebView *)webView didFailNavigation:(WKNavigation *)navigation withError:(NSError *)error {
    
    if (([error.domain isEqualToString:@"NSURLErrorDomain"] && error.code == -999) ||
        ([error.domain isEqualToString:@"WebKitErrorDomain"] && error.code == 102)) {
        return;
    }
    
    if (error.code == NSURLErrorTimedOut || error.code == NSURLErrorCannotConnectToHost || error.code == NSURLErrorNotConnectedToInternet) {
        [self.webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:@"about:blank"]]];
        NSLog( @"Please check your network connection and try again.");
    } else if (error.code == 101) {
        NSLog( @"Error loading URL, check your API Key & Sitename and try again");
    }
    
    }

- (void)webView:(WKWebView *)webView didFinishNavigation:(WKNavigation *)navigation {
    [self performSelector:@selector(executeScript) withObject:nil afterDelay:1.0 ];
}
#pragma mark - JSScript handler methods
- (void)userContentController:(WKUserContentController *)userContentController didReceiveScriptMessage:(WKScriptMessage *)message {
    [self hideLoader];
    NSDictionary *dict = message.body;
    NSString *str = [dict objectForKey:@"action"];
    if(str != nil && [str isEqualToString:@"showReCaptcha"]) {
        self.webView.hidden = false;
    }
    else {
        self.webView.hidden = true;
        
        if([dict objectForKey:@"error"] != nil || [dict objectForKey:@"captchaResponse"] != nil)
            self.captchaCompletion(dict);
    }
}
@end
