//
//  CaptchaWrapper.h
//
//  Copyright © 2020 Tanvi jain. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
/**
* Handles comunications with Google ReCaptcha decides and show caoptcha challenge on need and return callback to calling class.
*/
@interface CaptchaWrapper : NSObject

/**
 *  Initialise a `CaptchaWrapper` with a given captchaSiteKey.
 *
 *  @param captchaSiteKey is public key of Google ReCaptcha.
 *  @param baseUrl is URL by which domain is registered on Google Captcha console.
 *
 *  @return an initialised instance.
 */
- (instancetype)initReCaptchaWithApiKey:(NSString *
                                         _Nonnull)captchaSiteKey baseURL:(NSString * _Nonnull)baseUrl ;

/**
 *  Show Captcha challenge if needed and validate captcha automatically and return handler either containing capthca response or error.
 *
 *  @param viewC The viewcontroller whose view should present the webview.
 *  @param frame The frame of presented webview.
 *
 */
- (void)validateReCaptcha:(UIViewController * _Nonnull)viewC withFrame:(CGRect)frame completionHandler:(void (^_Nonnull)(NSDictionary * _Nonnull data))captchaComp;

@end

