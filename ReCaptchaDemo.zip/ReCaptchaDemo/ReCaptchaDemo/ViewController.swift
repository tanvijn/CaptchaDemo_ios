//
//  ViewController.swift
//  ReCaptchaDemo
//
//  Created by Tavni Jain on 2020-10-09.
//  Copyright © 2020 Tavni Jain. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITextFieldDelegate {
    var captchaWrapper:CaptchaWrapper? = nil
    var captchaResponse:String? = nil
    @IBOutlet var passwordTextField: UITextField!
    @IBOutlet var emailTextField: UITextField!
    @IBOutlet var btnCaptcha: UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()
        //set here your own captch site key and base url for the domian registered
        let baseUrl = "";
        let captchaSiteKey = "";
            captchaWrapper = CaptchaWrapper.init(reCaptchaWithApiKey: captchaSiteKey, baseURL: baseUrl)
    }
    @IBAction func pressCaptchaVerify(){
     //validate captcha and get callback
        captchaWrapper?.validateReCaptcha(self, withFrame:CGRect(x: 10, y: 20, width: self.view.frame.size.width-20, height: self.view.frame.size.height - 150), completionHandler:{(data) in
            if(data["captchaResponse"] != nil) {
                self.captchaResponse = data["captchaResponse"] as? String
                print(self.captchaResponse ?? "no captcha response")
                self.btnCaptcha.layer.borderColor = UIColor.green.cgColor
            }
            else {
                DispatchQueue.main.async
                           {
                               let alert = UIAlertController(title: "ERROR", message: data["error"] as? String ?? "Error with Captcha" , preferredStyle: UIAlertController.Style.alert)
                               alert.addAction(UIAlertAction(title: "OK", style: .cancel, handler:nil))
                               self.present(alert, animated: true, completion:nil)
                            self.btnCaptcha.layer.borderColor = UIColor.red.cgColor

                           }
            }
            
        })
    }
    @IBAction func pressSubmit (){
        if (captchaResponse != nil)
        {
            DispatchQueue.main.async
            {
                let alert = UIAlertController(title: "Success", message: "You may proceed!", preferredStyle: UIAlertController.Style.alert)
                alert.addAction(UIAlertAction(title: "OK", style: .cancel, handler:nil))
                self.present(alert, animated: true, completion:nil)
            }
        }
        else {
            DispatchQueue.main.async
            {
                let alert = UIAlertController(title: "Error", message: "Sorry! Capthca is needed!", preferredStyle: UIAlertController.Style.alert)
                alert.addAction(UIAlertAction(title: "OK", style: .cancel, handler:nil))
                self.present(alert, animated: true, completion:nil)
            }
        }
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        switch textField {
    
        case emailTextField:
            passwordTextField.becomeFirstResponder()
        default:
            passwordTextField.resignFirstResponder()
        }

        return true
    }
 
}

